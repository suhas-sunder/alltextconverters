import { useMemo } from "react";
import type { Route } from "./+types/text-to-pdf";

import { TextToPdfToolCard } from "../client/components/text-to-pdf/TextToPdfToolCard";
import { HowItWorksSection } from "../client/components/text-to-pdf/HowItWorksSection";
import { FaqSection } from "../client/components/text-to-pdf/FaqSection";

export const meta: Route.MetaFunction = () => [
  { title: "Text to PDF Converter | AllTextConverters" },
  {
    name: "description",
    content:
      "Convert text to a clean PDF in your browser. Paste or upload, format with headings and lists, then download as a PDF.",
  },
  { property: "og:title", content: "Text to PDF Converter | AllTextConverters" },
  {
    property: "og:description",
    content:
      "Turn text into a downloadable PDF locally in your browser. Format with bold, underline, lists, and headings, then export.",
  },
  { property: "og:type", content: "website" },
  {
    property: "og:url",
    content: "https://www.alltextconverters.com/text-to-pdf",
  },
  {
    property: "og:image",
    content: "https://www.alltextconverters.com/social-preview.png",
  },
  { name: "twitter:card", content: "summary_large_image" },
  { name: "twitter:title", content: "Text to PDF Converter | AllTextConverters" },
  {
    name: "twitter:description",
    content:
      "Convert text to PDF in your browser. Paste or upload, format quickly, then export to a PDF.",
  },
  { name: "robots", content: "index, follow" },
  { name: "theme-color", content: "#1e293b" },
  {
    rel: "canonical",
    href: "https://www.alltextconverters.com/text-to-pdf",
  },
];

export default function TextToPdfRoute() {
  const breadcrumbSchema = useMemo(
    () => ({
      "@context": "https://www.schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        {
          "@type": "ListItem",
          position: 1,
          name: "Home",
          item: "https://www.alltextconverters.com/",
        },
        {
          "@type": "ListItem",
          position: 2,
          name: "Text to PDF",
          item: "https://www.alltextconverters.com/text-to-pdf",
        },
      ],
    }),
    [],
  );

  return (
    <main className="min-h-screen font-sans bg-slate-100 text-slate-900">
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-10 sm:pb-16 pt-7 space-y-12">
        <TextToPdfToolCard />
        <HowItWorksSection />
        <FaqSection />
      </section>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
      />
    </main>
  );
}
